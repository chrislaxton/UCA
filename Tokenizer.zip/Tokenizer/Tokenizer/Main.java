package Tokenizer;

import java.util.*;
import java.io.*;

public class Main {
	    public static void main(String [] args) throws IOException  {
	    	
	    	ArrayList<String> freedom = new ArrayList<String>();
	    //	String turd = "C:\\\\temp\\\\Programming Languages\\\\ArrayTest\\\\Main.jack";
	    	String turd = "C:\\\\temp\\\\Programming Languages\\\\Square\\\\Main.jack";
	    	freedom = FileRead.readme(turd);
	    	ArrayList<String> winner = new ArrayList<String>();
	    	ArrayList<String> end = new ArrayList<String>();
	
	    	for (int z=0; z<freedom.size(); z++)
			{
				Tokens.splitdata(freedom.get(z));
			}

			winner = Tokens.returndata();
		
			end.add("<tokens>");
			
			for (int d =0; d<winner.size(); d++)
			{
				end.add(Tokens.gettoken(winner.get(d)));
			}
			
			end.add("</tokens>");
			
			for (int x=0; x<end.size(); x++)
			{
				System.out.println(end.get(x));
			}
	    }
}
	     