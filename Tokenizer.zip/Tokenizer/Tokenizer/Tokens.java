
package Tokenizer;

import java.util.*;

public final class Tokens {
		
		public static ArrayList<String> total = new ArrayList<String>();

		public static void splitdata(String turd)
		{
			int a=0;
			int b=turd.length();
			ArrayList<Character> splitter = new ArrayList<Character>();
			
			String temp = new String();
			Package godzilla  = new Package();
			
			if (turd.length() == 0)
				return;
			
			if ((turd.charAt(a))=='"')
			{
				splitter.add(turd.charAt(a));
				a++;
				
				while (turd.charAt(a)!='"')
				{
					splitter.add(turd.charAt(a));
					a++;
				}
				
				splitter.add(turd.charAt(a));
				a++;
				
				for (int d=0; d<splitter.size(); d++)
				{
					temp = temp.concat(Character.toString(splitter.get(d)));
				}
				
				godzilla.a = temp;
					
				if (turd.charAt(a)==' ')
					a++;
				
				godzilla.b = turd.substring(a, turd.length());
				
				total.add(godzilla.a);
				
				if ((godzilla.b).length()!=0)
				{
					splitdata(godzilla.b);
					return;
				}
				else
					return;
			}
			
			if (turd.charAt(a) == ' ')
			{
				if ((a+1)>(turd.length()-1))
					return;
				else
					a++;
			}
			
			int init_a = a;
			
			if ((turd.charAt(a)=='(')||(turd.charAt(a)==')')||(turd.charAt(a)=='[')||(turd.charAt(a)==']')||
					(turd.charAt(a)=='{')||(turd.charAt(a)=='}')||(turd.charAt(a)==',')||
					(turd.charAt(a)==';')||(turd.charAt(a)=='=')||(turd.charAt(a)=='.')||
					(turd.charAt(a)=='+')||(turd.charAt(a)=='-')||(turd.charAt(a)=='*')||
					(turd.charAt(a)=='/')||(turd.charAt(a)=='&')||(turd.charAt(a)=='|')||
					(turd.charAt(a)=='~')||(turd.charAt(a)=='<')||(turd.charAt(a)=='>'))
			{
				if (((turd.charAt(a) == '/')&&(turd.charAt(a+1) == '/'))||((turd.charAt(a) == '/')&&(turd.charAt(a+1) == '*'))||
						(turd.charAt(a) == '*')&&(turd.charAt(a+1) == ' ')||((turd.charAt(a) == '*')&&(turd.charAt(a+1) == '/')))
					return;
				
				
				godzilla.a = Character.toString(turd.charAt(a));
				godzilla.b = turd.substring(a+1, turd.length());
				
				total.add(godzilla.a);
				
				if ((godzilla.b).length()!=0)
				{
					splitdata(godzilla.b);
					return;
				}
				
				else
					return;
			}
			
			while (a<b)
			{
				if ((turd.charAt(a)!=' ')&&(turd.charAt(a)!='(')&&(turd.charAt(a)!=')')&&(turd.charAt(a)!='[')&&(turd.charAt(a)!=']')&&
				(turd.charAt(a)!='{')&&(turd.charAt(a)!='}')&&(turd.charAt(a)!=',')&&
				(turd.charAt(a)!=';')&&(turd.charAt(a)!='=')&&(turd.charAt(a)!='.')&&
				(turd.charAt(a)!='+')&&(turd.charAt(a)!='-')&&(turd.charAt(a)!='*')&&
				(turd.charAt(a)!='/')&&(turd.charAt(a)!='&')&&(turd.charAt(a)!='|')&&
				(turd.charAt(a)!='~')&&(turd.charAt(a)!='<')&&(turd.charAt(a)!='>'))
				{
					splitter.add(turd.charAt(a));
					a++;
				}
				
				else
					break;
				
			}
			
			int final_a = a;
			int c = 0;
			
			if (a>0)
			{
				c = final_a - init_a;
			}
				
			
			for (int d=0; d<c; d++)
			{
				temp = temp.concat(Character.toString(splitter.get(d)));
			}
			
			godzilla.a = temp;
				
			if (turd.charAt(a)==' ')
				a++;
			
			godzilla.b = turd.substring(a, turd.length());
			
			total.add(godzilla.a);
			
			if ((godzilla.b).length()!=0)
			{
				splitdata(godzilla.b);
				return;
			}
			else
				return;
			}
			
		public static ArrayList<String> returndata()
		{
			return total;
		}
		
		
		public static String gettoken(String token)
		{
			boolean bubble = true;
			
			if ((token.equals("("))||(token.equals(")"))||(token.equals("["))||(token.equals("]"))||
					(token.equals("{"))||(token.equals("}"))||(token.equals(","))||
					(token.equals(";"))||(token.equals("="))||(token.equals("."))||
					(token.equals("+"))||(token.equals("-"))||(token.equals("*"))||
					(token.equals("/"))||(token.equals("&"))||(token.equals("|"))||
					(token.equals("~"))||(token.equals("<"))||(token.equals(">")))
			{
				return ("	<symbol>"+token+"</symbol>");
			}

			else if ((token.equals("class"))||(token.equals("constructor"))||(token.equals("method"))||
					(token.equals("function"))||(token.equals("int"))||(token.equals("boolean"))||
					(token.equals("char"))||(token.equals("void"))||(token.equals("var"))||
					(token.equals("static"))||(token.equals("field"))||(token.equals("let"))||
					(token.equals("do"))||(token.equals("if"))||(token.equals("else"))||(token.equals("while"))||
					(token.equals("return"))||(token.equals("true"))||(token.equals("false"))||(token.equals("null"))||
					(token.equals("this")))
			{
				return ("	<keyword>"+token+"</keyword>");
			}
			
			else if (token.startsWith("0") || token.startsWith("1")||token.startsWith("2")||token.startsWith("3")||token.startsWith("4")||
					token.startsWith("5")||token.startsWith("6")||token.startsWith("7")||token.startsWith("8")||
					token.startsWith("9"))
			{
				for (int a=0;a<token.length();a++)
				{
					if ((token.charAt(a) == '0' || token.charAt(a)=='1')||(token.charAt(a)=='2')||(token.charAt(a)=='3')||(token.charAt(a)=='4')||
							(token.charAt(a)=='5')||(token.charAt(a)=='6')||(token.charAt(a)=='7')||(token.charAt(a)=='8')||
							(token.charAt(a)=='9'))
						bubble = true;
					else
						bubble = false;
				}
				
				if (bubble)
					return ("	<integer>"+token+"</integer>");
			}
			
			else if ((token.charAt(0)=='"')&&(token.charAt(token.length()-1)=='"'))
				return ("	<string>"+token+"</string");
				
			else if (Character.isLetter(token.charAt(0)))
			{
				boolean splat = true;
				for (int f=1; f<token.length();f++)
				{
					if (Character.isLetterOrDigit(token.charAt(f)))
						splat = true;
					else
						splat = false;
				}
				
				if (splat)
					return ("	<identifier>"+token+"</identifier>"); 
				
			}
			
			return ("unidentified object: "+token);
			
		}
}