package Tokenizer;

	public class Package{
		public String a;
		public String b;
		
	}
