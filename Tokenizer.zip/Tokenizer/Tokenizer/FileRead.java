package Tokenizer;

import java.io.*;
import java.util.*;

public class FileRead {

	public static ArrayList<String> readme (String turd) throws IOException
	{
		ArrayList<String> bogo = new ArrayList<String>();
		String filename = turd;
		BufferedReader br = null;
		FileReader fr = null;
		
		try {
			fr = new FileReader(filename);
			br = new BufferedReader(fr);

			String current = null;
			
			while((current = br.readLine()) != null)
			{
					bogo.add(current);
				
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
		
		return bogo;
	}

}
