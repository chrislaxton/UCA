package CarBoop;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame {


	public static void main(String[] args) {
		JFrame frame = new JFrame("Car Trade In Value!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(915, 443);
		
		MainPanel mainPanel = new MainPanel();
		frame.getContentPane().add(mainPanel);
		mainPanel.setLayout(null);
		
		frame.pack();
		frame.setVisible(true);
	}

}
