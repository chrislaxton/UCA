//Chris Laxton
//ID: 001164996
//Project 1 

package CarBoop;

import java.io.*;
import java.util.*;

public class Predictor implements PredictorADT{


	//Create private variables within predictor object
	private String myFileName;
	private ArrayList<Car> train;
	private ArrayList<Car> goob;
	private int right;
	private int total;
	private double accur;


	//Constructor for predictor class
	public Predictor (String filename)
	{
		myFileName = filename; //Sets myFileName to filename (data file passed in)
		train = new ArrayList<Car>(initalize(myFileName)); //reads the data file and stores into an ArrayList<Car>
		goob = teachme(train);	//Goes through and adds each unique Car into a new ArrayList<Car>

	}

	//Calls getPrediction and adds to right counter, and total counter after each iteration. Returns accuracy as a double
	public double getTrainingAccuracy()
	{
		right = 0;	//Correct Number
		total = 0;	//Total Number (Size)
		accur = 0.0; //Accuracy as a double

		for(int i = 0 ; i < train.size() ; i++)
		{
			if ((getPrediction(train.get(i))).equals(train.get(i).getRating()))
			{
				right++;
			}
			total++;
		}

		accur = (double)right/(double)total;
		return accur;
	}

	
	//Returns the rating of the car being passed into the function
	public String getPrediction(CarADT instance) {
		Car turd = new Car();	//create new Car
		turd = (Car)instance;	//typecast to Car

		for (int i = 0; i < goob.size(); i++)
		{
			if(goob.get(i).equals(turd))
			{
				return goob.get(i).getRating();	//If the Car.equals the predicting data then get that rating
			}
		}

		return "unacc";	//otherwise return unacc

	}
	
	
	//Takes in a single car
	public ArrayList<Car> getPrediction(Car car)
	{
		//Create new ArrayList of Cars
		ArrayList<Car> pachino = new ArrayList<Car>();
		
		//Go through training data to see if car equals any of the existing cars
		for (int i = 0; i < goob.size(); i++)
		{
			if(goob.get(i).equals3(car))
			{
				//If so, add to pachino and return
				pachino.add(goob.get(i));
				return pachino;
			}
		}
		
		//Check to see the next closely related cars
		for (int i = 0; i < goob.size(); i++)
		{
			if(goob.get(i).equals2(car))
			{
				//Adds the next 3 closest related cars
				pachino.add(goob.get(i));
				
				if(pachino.size()==3)
				{
					//Once there are 3, return pachino
					return pachino;
				}
			}
		}
		
		
		//Return arraylist
		return pachino;
	}

	//Reads the file that is passed into the Predictor Class
	@SuppressWarnings("resource")
	private ArrayList<Car> initalize(String file)
	{
		ArrayList<Car> cars = new ArrayList<Car>();	//Create new ArrayList<Car>
		try {
			File f = new File(file);		//File 
			Scanner sc = new Scanner(f);	//Scanner

			while(sc.hasNextLine()){
				String line = sc.nextLine();	//Scan the nextline in the arraylist
				String[] details = line.split(",");	//Split up by comma's
				
				//Read each array element
				String buying = details[0];
				String maint = details[1];
				if(details[2].equals("5more"))	//if numDoors = "5more" then set to "5"
				{
					details[2] = "5";
				}
				int persons = Integer.parseInt(details[2]);
				if(details[3].equals("more"))	//if numPersons = "more" then set to "5"
				{
					details[3] = "5";
				}
				int doors = Integer.parseInt(details[3]);
				String lug = details[4];
				String safety = details[5];
				String rating = null;

				if(details[6] != null)
				{
					rating = details[6];
				}

				//Add a new car with details[] elements to the cars ArrayList
				cars.add(new Car(buying,maint,doors,persons,lug,safety,rating));

			}


		} catch (FileNotFoundException e) {         
			e.printStackTrace();
		}
		
		//Return cars
		return cars;
	}

	//Algorithm for learning how to determine the rating of a car
	//Input: ArrayList<Car> car
	//Output: ArrayList<Car> boop
	//Function: Reads the data from the passed in ArrayList<Car> (this being our data file) 
	//and stores each unique element in the arraylist in a separate arraylist
	public ArrayList<Car> teachme(ArrayList<Car> car)
	{

		ArrayList<Car> boop = new ArrayList<Car>();	//Create new ArrayList<Car> boop
		int count = 0;
		boolean noop;	//Create a boolean 
		boop.add(car.get(0));	//Add first element to boop


		//Iterate through the data file arraylist and the newly created arraylist
		for(int i = 0 ; i < car.size() ; i++)
		{
			for(int j=0 ; j<boop.size() ; j++)
			{
				if(car.get(i).equals(boop.get(j)))
				{
					count++;
				}
				
				if(count>0)
				{
					count = 0;
					break;
				}
				else
				{
					count = 0;
					boop.add(car.get(i));
					break;
				}
			}
		}

		//Return ArrayList<Car> boop
		return boop;
	}

	//Returns the train data (Data file read in)
	public ArrayList<Car> getTrain()
	{
		return train;
	}
	
	//Returns the goob data (new ArrayList<Car> of unique cars)
	public ArrayList<Car> getGoob()
	{
		return goob;
	}
	
}
