//Chris Laxton
//ID: 001164996
//Project 1 

package CarBoop;

import java.io.*;
import java.util.*;

public class PredictorTester {

	public static void main(String args []) throws IOException
	{

		//Create new predictor object named turd
		Predictor turd = new Predictor("./carTrain.DATA");


		//Create new ArrayList<car> named flubber
	//	ArrayList<Car> flubber = new ArrayList<Car>(turd.getTrain());
		ArrayList<Car> bilbo = new ArrayList<Car>(turd.getGoob());

		//Print out training data
		for(int i = 0; i < bilbo.size(); i++)
		{
			System.out.println(bilbo.get(i));
		}

		//Print out size of training data
		System.out.println("Size of Training Date: " +bilbo.size());

		//Print out training accuracy for training data
		System.out.println("Accuracy for Training Data: " +turd.getTrainingAccuracy());
	}

}
