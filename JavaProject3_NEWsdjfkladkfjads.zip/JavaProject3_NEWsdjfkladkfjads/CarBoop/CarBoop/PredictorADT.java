//Chris Laxton
//ID: 001164996
//Project 1 

package CarBoop;

public interface PredictorADT {
	public double getTrainingAccuracy ();
	public String getPrediction (CarADT instance);
}
