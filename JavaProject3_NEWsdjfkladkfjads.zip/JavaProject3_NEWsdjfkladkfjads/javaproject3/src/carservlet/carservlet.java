package carservlet;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CarBoop.*;

/**
 * Servlet implementation class carservlet
 */
@WebServlet("/carservlet")
public class carservlet extends HttpServlet {
	
	//Declare Global Variables
	Car boop = new Car();
	ArrayList<Car> hoop = new ArrayList<Car>();
	Predictor goop = new Predictor("C:\\temp\\JavaProject3_NEW\\javaproject3\\src\\carservlet\\carTrain.DATA");
	int greengoblin = 0;
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public carservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		//When user presses login button
		if(request.getParameter("login")!=null)
		{	
			//If Incorrect, display a form accordingly
			if ((!(request.getParameter("username").equals("Chris"))) || (!(request.getParameter("password").equals("isCool"))))
			{
				response.getWriter().append("<form name=\"errorForm\" method=\"post\" action=\"carservlet\">");
				response.getWriter().append("<h2>Whoops You Entered the Wrong Username and Password!</h2>");
				response.getWriter().append("<input type=\"submit\" value=\"Ok\" name = \"back\"/>");
				response.getWriter().append("</form>");
				response.getWriter().close();
			}
			
			//Otherwise proceed to FirstPage.jsp
			else
			{
				response.sendRedirect("FirstPage.jsp");
				return;
			}
		}
		
		
		if(request.getParameter("back")!=null)
		{
			response.sendRedirect("index.html");
			return;
		}
		
		if(request.getParameter("submitme")!=null)
		{
			//Create an error string
			String error = "Whoops! You Missed Some Entries! Please Make Sure You Enter Everything!";
			if ((request.getParameter("greengoblin").equals("")) || (request.getParameter("trunk").equals(""))||(request.getParameter("price").equals(""))
					||(request.getParameter("doors").equals(""))||(request.getParameter("maint").equals(""))||(request.getParameter("people").equals(""))
					||(request.getParameter("safety").equals("")))
			{		
				
				//Inform user they missed some entries
				response.getWriter().append("<form name=\"errorForm\" method=\"post\" action=\"carservlet\">");
				response.getWriter().append("<h2>" +error + "</h2>");
				response.getWriter().append("<input type=\"submit\" value=\"Oh Bummer! Let Me Do This Again\" name = \"tryagain\"/>");
				response.getWriter().append("</form>");
				response.getWriter().close();
			}

			//Sets all of the values to values selected
			boop.setBuying(request.getParameter("price"));
			boop.setMaint(request.getParameter("maint"));
			boop.setTrunk(request.getParameter("trunk"));
			boop.setDoors(Integer.parseInt(request.getParameter("doors")));
			boop.setPersons(Integer.parseInt(request.getParameter("people")));
			boop.setSafety(request.getParameter("safety"));

			//Gets prediction and returns an arraylist
			hoop = goop.getPrediction(boop);
			//Cars returned from search
			String pokemon = "pokemon";
			String monster = "";
			
			//If exact match
			if (hoop.size()==1)
			{
				//Add exact match to radio buttons
				monster = "<input type=\"radio\" name=\"match\" value=\"" +hoop.get(0).getRating() +"\" />" + hoop.get(0).toString(); 
			}
				
			//Else add 3 closest matches to radio buttons
			else
			{
				for (int i = 0; i <hoop.size();i++)
				{
					monster += "<input type=\"radio\" name=\"match\" value=\"" +hoop.get(i).getRating() +"\" />" + hoop.get(i).toString() + "<br>";
				}
			}

			//Set the attribute of pokemon to the arraylist monster
			request.setAttribute(pokemon, monster);
			
			//Convert the purchase price to a string
			greengoblin = Integer.parseInt(request.getParameter("greengoblin"));
			//Navigate to SecondPage.jsp
			RequestDispatcher rd=request.getRequestDispatcher("SecondPage.jsp");   
			rd.forward(request,response);
		}

		//If secondpage button is pressed
		if(request.getParameter("showmethemoney")!=null)
		{
			//If a selection was made
			if (request.getParameter("match")!=null)
			{
				//Gives the trade-in value for the car passed in 
				if (request.getParameter("match").equals("unacc"))
				{
					greengoblin = (int) (greengoblin*(0.05));
				}
				else if (request.getParameter("match").equals("acc"))
				{
					greengoblin = (int) (greengoblin*(0.10));
				}
				else if (request.getParameter("match").equals("good"))
				{
					greengoblin = (int) (greengoblin*(0.15));
				}
				else if (request.getParameter("match").equals("vgood"))
				{
					greengoblin = (int) (greengoblin*(0.20));
				}
				
				
				request.setAttribute("greengoblin", (Integer)greengoblin);
				
				RequestDispatcher rd=request.getRequestDispatcher("ThirdPage.jsp");   
				rd.forward(request,response);
			}
			
			else
			{
				response.getWriter().append("<form name=\"errorForm\" method=\"post\" action=\"carservlet\">");
				response.getWriter().append("<h2>" + "Be Sure To Select The Closest Car" + "</h2>");
				response.getWriter().append("<input type=\"submit\" value=\"Oops\" name = \"tryagain\"/>");
				response.getWriter().append("</form>");
				response.getWriter().close();
			}
		}
		
		//Logs out of pages
		if(request.getParameter("logout")!=null)
		{
			response.sendRedirect("index.html");
			return;
		}
		
		//Lets user do this process again
		if(request.getParameter("tryagain")!=null)
		{
			response.sendRedirect("FirstPage.jsp");
			return;
		}

		//If redirected to anything else it goes here
		else
			response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
