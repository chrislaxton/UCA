package project3;

import java.util.*;

public class BellmanFord {	
	
	//Constructor (Gets Shortest Paths)
	public BellmanFord(ArrayList<Vertex> bob, Vertex source)
	{
		//Assigns all distances and prev nodes to 0.
		for(int i = 0; i < bob.size();i++)
		{
			bob.get(i).setDistance(Double.POSITIVE_INFINITY);
			bob.get(i).setprev(null);
		}
		
		//Sets source node to be 0 distance
		source.setDistance(0);
		int i = 0;
		
		//Sort through bob.size()-1
		while (i < bob.size()-1)
		{
			//Get all edges for each source passed in
		for(int j = 0; j < source.getAdjacenciesList().size(); j++){
			Edge edge = source.getAdjacenciesList().get(j);
			//Sets v to the vertex it is linked to
			Vertex v = edge.geteVertex();

			//if the new distance is less than the current vertex distance
			if((source.getDistance() + edge.getWeight()) < v.getDistance() ){
			v.setDistance(source.getDistance()+edge.getWeight());
			//Sets the previous vertex to the current vertex passed in
			v.setprev(source);
			}	
		}
		//Sets current source to be true
		source.setVisited(true);
		//Add counter
		i++;
		//While source.isVisited Assign source to next vertex passed in by bob
		while(source.isVisited())
		{
		source = bob.get(i);
		}
		}
		
		
	}
	
	public ArrayList<Vertex> getShortestPathTot(Vertex o){
		//Creates a new ArrayList 
		ArrayList<Vertex> p = new ArrayList<Vertex>();

		//For each vertex that is not null, get the previous vertex and add it to ArrayList
		for(Vertex vertex = o ; vertex != null; vertex = vertex.getprev()){
			p.add(vertex);
		}

		//reverse the order of ArrayList p
		Collections.reverse(p);

		//return P
		return p;
	}
	
}
