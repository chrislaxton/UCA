package project3;

public class Edge {

	//Private Data Variables
	private double weight;
	private Vertex sVertex;
	private Vertex eVertex;


	//Constructor
	public Edge(double weight, Vertex sVertex, Vertex eVertex) {
		this.weight = weight;
		this.sVertex = sVertex;
		this.eVertex = eVertex;
	}

	//Getters and Setters
	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public Vertex getsVertex() {
		return sVertex;
	}

	public void setsVertex(Vertex sVertex) {
		this.sVertex = sVertex;
	}

	public Vertex geteVertex() {
		return eVertex;
	}

	public void seteVertex(Vertex eVertex) {
		this.eVertex = eVertex;
	}
	
	public String toString()
	{
		return "";
	}
}
