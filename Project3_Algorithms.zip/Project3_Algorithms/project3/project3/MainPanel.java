package project3;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;

public class MainPanel extends JPanel {

	private DijkstraShortestPath shortestPath;
	private BellmanFord bellmanford;
	private mappanel mapPan;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	
	public Vertex getVertex(String a, ArrayList<Vertex> Bob)
	{
		Vertex jiggle = new Vertex();
		
		for(int i = 0; i< Bob.size();i++)
		{
			if(Bob.get(i).toString().equals(a))
			{
				jiggle = Bob.get(i);
				break;
			}
		}
		return jiggle;
	}

	public MainPanel(JFrame a)
	{

		//Create a new ArrayList of Vertex called hoopstar
		ArrayList<Vertex> hoopstar = new ArrayList<Vertex>();
		mapPan = new mappanel();
		a.getContentPane().add(mapPan);
		mapPan.setVisible(false);

		//Create each Vertex
		Vertex vertexA = new Vertex("College Square");
		Vertex vertexB = new Vertex("Lewis Science Center");
		Vertex vertexC = new Vertex("Speech Language Hearing");
		Vertex vertexD = new Vertex("Math-Comp Science");
		Vertex vertexE = new Vertex("Burdick");
		Vertex vertexF = new Vertex("Prince Center");
		Vertex vertexG = new Vertex("Torreyson Library");
		Vertex vertexH = new Vertex("Old Main");
		Vertex vertexI = new Vertex("Maintenance College");
		Vertex vertexJ = new Vertex("Police Dept");
		Vertex vertexK = new Vertex("Fine Art");
		Vertex vertexL = new Vertex("McAlister Hall");
		Vertex vertexM = new Vertex("Student Center");
		Vertex vertexN = new Vertex("Wingo");
		Vertex vertexO = new Vertex("Student Health Center");
		Vertex vertexP = new Vertex("New Business Building");
		Vertex vertexQ = new Vertex("Oak Tree Apt");
		Vertex vertexR = new Vertex("Brewer-Hegeman");
		Vertex vertexS = new Vertex("Bear Village Apt");


		//Adds each vertex to hoopstar
		hoopstar.add(vertexD);
		hoopstar.add(vertexE);
		hoopstar.add(vertexF);
		hoopstar.add(vertexG);
		hoopstar.add(vertexH);
		hoopstar.add(vertexI);
		hoopstar.add(vertexJ);
		hoopstar.add(vertexK);
		hoopstar.add(vertexL);
		hoopstar.add(vertexM);
		hoopstar.add(vertexN);
		hoopstar.add(vertexO);
		hoopstar.add(vertexP);
		hoopstar.add(vertexQ);
		hoopstar.add(vertexR);
		hoopstar.add(vertexS);
		hoopstar.add(vertexA);
		hoopstar.add(vertexB);
		hoopstar.add(vertexC);


		//Adds each edge to each vertex
		vertexA.addEdge(new Edge(200,vertexA,vertexB));
		vertexA.addEdge(new Edge(300,vertexA,vertexF));
		vertexB.addEdge(new Edge(250,vertexB,vertexC));
		vertexB.addEdge(new Edge(150,vertexB,vertexD));
		vertexB.addEdge(new Edge(200,vertexB,vertexA));
		vertexC.addEdge(new Edge(120,vertexC,vertexI));
		vertexC.addEdge(new Edge(250,vertexC,vertexB));
		vertexC.addEdge(new Edge(100,vertexC,vertexE));
		vertexD.addEdge(new Edge(80,vertexD,vertexF));
		vertexD.addEdge(new Edge(40,vertexD,vertexG));
		vertexD.addEdge(new Edge(30,vertexD,vertexE));
		vertexD.addEdge(new Edge(150,vertexD,vertexB));
		vertexE.addEdge(new Edge(80,vertexE,vertexG));
		vertexE.addEdge(new Edge(300,vertexE,vertexI));
		vertexE.addEdge(new Edge(200,vertexE,vertexL));
		vertexE.addEdge(new Edge(100,vertexE,vertexC));
		vertexE.addEdge(new Edge(30, vertexE,vertexD));
		vertexF.addEdge(new Edge(100,vertexF,vertexJ));
		vertexF.addEdge(new Edge(30,vertexF,vertexG));
		vertexF.addEdge(new Edge(300,vertexF,vertexA));
		vertexG.addEdge(new Edge(30,vertexG,vertexH));
		vertexG.addEdge(new Edge(40,vertexG,vertexD));
		vertexG.addEdge(new Edge(30,vertexG,vertexF));
		vertexG.addEdge(new Edge(80,vertexG,vertexE));
		vertexH.addEdge(new Edge(50,vertexH,vertexJ));
		vertexH.addEdge(new Edge(30,vertexH,vertexG));
		vertexH.addEdge(new Edge(90,vertexH,vertexK));
		vertexH.addEdge(new Edge(100,vertexH,vertexL));
		vertexI.addEdge(new Edge(150,vertexI,vertexL));
		vertexI.addEdge(new Edge(160,vertexI,vertexQ));
		vertexI.addEdge(new Edge(150,vertexI,vertexP));
		vertexI.addEdge(new Edge(100,vertexI,vertexN));
		vertexI.addEdge(new Edge(120,vertexI,vertexC));
		vertexI.addEdge(new Edge(300,vertexI,vertexE));
		vertexJ.addEdge(new Edge(100,vertexJ,vertexO));
		vertexJ.addEdge(new Edge(100,vertexJ,vertexF));
		vertexJ.addEdge(new Edge(50,vertexJ,vertexK));
		vertexK.addEdge(new Edge(80,vertexK,vertexM));
		vertexK.addEdge(new Edge(180,vertexK,vertexL));
		vertexK.addEdge(new Edge(50,vertexK,vertexJ));
		vertexK.addEdge(new Edge(90,vertexK,vertexH));
		vertexL.addEdge(new Edge(100,vertexL,vertexM));
		vertexL.addEdge(new Edge(200,vertexL,vertexE));
		vertexL.addEdge(new Edge(100,vertexL,vertexH));
		vertexL.addEdge(new Edge(180,vertexL,vertexK));
		vertexL.addEdge(new Edge(50,vertexL,vertexN));
		vertexL.addEdge(new Edge(150,vertexL,vertexI));
		vertexM.addEdge(new Edge(50,vertexM,vertexO));
		vertexM.addEdge(new Edge(100,vertexM,vertexL));
		vertexM.addEdge(new Edge(80,vertexM,vertexK));
		vertexM.addEdge(new Edge(100,vertexM,vertexN));
		vertexM.addEdge(new Edge(110,vertexM,vertexP));
		vertexN.addEdge(new Edge(50,vertexN,vertexP));
		vertexN.addEdge(new Edge(100,vertexN,vertexI));
		vertexN.addEdge(new Edge(50,vertexN,vertexL));
		vertexN.addEdge(new Edge(100,vertexN,vertexM));
		vertexO.addEdge(new Edge(200,vertexO,vertexR));
		vertexO.addEdge(new Edge(50,vertexO,vertexM));
		vertexO.addEdge(new Edge(100,vertexO,vertexJ));
		vertexP.addEdge(new Edge(20,vertexP,vertexR));
		vertexP.addEdge(new Edge(50,vertexP,vertexN));
		vertexP.addEdge(new Edge(110,vertexP,vertexM));
		vertexP.addEdge(new Edge(30,vertexP,vertexQ));
		vertexQ.addEdge(new Edge(40,vertexQ,vertexR));
		vertexQ.addEdge(new Edge(160,vertexQ,vertexI));
		vertexQ.addEdge(new Edge(30,vertexQ,vertexP));
		vertexR.addEdge(new Edge(350,vertexR,vertexS));
		vertexR.addEdge(new Edge(200,vertexR,vertexO));
		vertexR.addEdge(new Edge(20,vertexR,vertexP));
		vertexS.addEdge(new Edge(350,vertexS,vertexR));


		//SetBackground Color and size for panel
		setBackground(Color.GRAY);
		setPreferredSize(new Dimension(1000, 500));
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBounds(0, 0, 1000, 750);
		add(panel);
		panel.setLayout(null);
		
		//Creates a new label
		JLabel lblNewLabel = new JLabel("Select Starting Point");
		lblNewLabel.setBounds(80, 129, 170, 14);
		panel.add(lblNewLabel);
		lblNewLabel.setBackground(Color.GREEN);
		lblNewLabel.setForeground(Color.GREEN);
		
		//Creates a new label
		JLabel lblNewLabel_1 = new JLabel("Select End Point");
		lblNewLabel_1.setBounds(621, 129, 170, 14);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(Color.GREEN);
		
		//creates a new comboBox
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(80, 172, 170, 20);
		panel.add(comboBox);
		comboBox.addItem(hoopstar.get(0));

		//creates a new comboBox
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(621, 171, 170, 22);
		panel.add(comboBox_1);
		for (int i = 0; i < hoopstar.size();i++)
		{
			comboBox_1.addItem(hoopstar.get(i));
		}
		
		//Creates a new Label
		JLabel lblNewLabel_2 = new JLabel("Shorest Path!");
		lblNewLabel_2.setBounds(83, 238, 167, 14);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(Color.GREEN);
		
		//Creates a new Label
		JLabel lblNewLabel_3 = new JLabel("Distance");
		lblNewLabel_3.setBounds(621, 238, 254, 14);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setForeground(Color.GREEN);
		
		//Creates a new textPane
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBounds(621, 267, 254, 140);
		panel.add(textPane_1);
		
		//Creates a Process Button
		JButton btnNewButton = new JButton("Process!");
		btnNewButton.setBounds(414, 171, 128, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Use Maps?");
		btnNewButton_1.setBounds(414, 234, 128, 23);
		panel.add(btnNewButton_1);
		btnNewButton_1.setVisible(false);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(80, 267, 271, 140);
		panel.add(textPane);
		
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				panel.setVisible(false);
				Vertex joe = (Vertex) comboBox.getSelectedItem();
				shortestPath = new DijkstraShortestPath(joe);
				Vertex bob = (Vertex) comboBox_1.getSelectedItem();
				mapPan.passPath(shortestPath.getShortestPathTo(bob));
				mapPan.setVisible(true);
			}
			
		});
		
		Vertex joe = getVertex(comboBox.getSelectedItem().toString(),hoopstar);
		//shortestPath = new DijkstraShortestPath(joe);
		bellmanford = new BellmanFord(hoopstar,joe);
		
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(buttonGroup.getSelection().getActionCommand().equals("Dijkstra"))
				{
					Vertex bob = (Vertex) comboBox_1.getSelectedItem();
					shortestPath = new DijkstraShortestPath(joe);
					textPane.setText(""+shortestPath.getShortestPathTo(bob));
					textPane_1.setText(""+bob.getDistance());
					btnNewButton_1.setVisible(true);
					
				}
				else if(buttonGroup.getSelection().getActionCommand().equals("BellmanFord"))
				{
					Vertex bob = (Vertex) comboBox_1.getSelectedItem();
					textPane.setText(""+bellmanford.getShortestPathTot(bob));
					textPane_1.setText(""+bob.getDistance());
					btnNewButton_1.setVisible(true);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Be Sure to Click Which Algorithm to Use!");
				}
			}});
		
		int deltaY = 0;
		
		ArrayList<String> gumpy = new ArrayList<String>();
		gumpy.add("Dijkstra");
		gumpy.add("BellmanFord");
		for (String s : gumpy) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(430, 50+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel.add(rdbtnRb);
			deltaY += 29;
		}
		
	}
}
