package project3;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;


public class MainFrame {


	public static void main(String[] args) {
		JFrame frame = new JFrame("UCA Maps");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000, 750);

		MainPanel mainPanel = new MainPanel(frame);
		frame.getContentPane().add(mainPanel);
		mainPanel.setLayout(null);

		frame.pack();
		frame.setVisible(true);
	}

}
