package project3;

import java.util.*;

public class Vertex implements Comparable<Vertex> {

	//Private Data Variables
	private String name;
	private ArrayList<Edge> adjacenciesList;
	private boolean visited;
	private Vertex prev;
	private double distance = Double.MAX_VALUE;

	//Constructor
	
	public Vertex ()
	{
		this.name = null;
		this.adjacenciesList = new ArrayList<Edge>();
	}
	public Vertex(String name) {
		this.name = name;
		this.adjacenciesList = new ArrayList<Edge>();
	}


	//Getter and Setters
	public void addEdge(Edge edge) {
		this.adjacenciesList.add(edge);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Edge> getAdjacenciesList() {
		return adjacenciesList;
	}

	public void setAdjacenciesList(ArrayList<Edge> adjacenciesList) {
		this.adjacenciesList = adjacenciesList;
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	public Vertex getprev() {
		return prev;
	}

	public void setprev(Vertex prev) {
		this.prev = prev;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public String toString() {
		return this.name;
	}

	public int compareTo(Vertex otherVertex) {
		return Double.compare(this.distance, otherVertex.getDistance());
	}
}
