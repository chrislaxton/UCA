package project3;

import java.util.*;

public class DijkstraShortestPath {

	//Function getShortestPaths
	//Input: Vertex a
	//Output: void
	//Makes a shortest path to each vertex in the graph
	public DijkstraShortestPath(Vertex timmy){
		
		Vertex a = timmy;

		//Sets the distance to 0
		a.setDistance(0);
		//Creates a priority queue
		PriorityQueue<Vertex> tooth = new PriorityQueue<>();
		//Adds first vertex to priority queue along with edges
		tooth.add(a);
		//Sets the first vertex to be true for visited
		a.setVisited(true);


		while( !tooth.isEmpty() ){
			//Gets the minimum distance vertex in the queue
			Vertex sVertex = tooth.poll();

			//For each edge in the graph
			for(Edge edge : sVertex.getAdjacenciesList()){

				//Sets v to the vertex it is linked to
				Vertex v = edge.geteVertex();

				//For each edge not visited in the queue
				if(!v.isVisited())
				{
					//Sets the new distance from the current vertex to the vertex it is connected to
					double newD = sVertex.getDistance() + edge.getWeight();

					//if the new distance is less than the previous distance
					if( newD < v.getDistance() ){
						//Remove it from the priority queue and update the new distance
						tooth.remove(v);
						v.setDistance(newD);
						//Sets the previous vertex to the minimum distance vertex
						v.setprev(sVertex);
						//Add it back to priority queue
						tooth.add(v);
					}
				}
			}
			//Set the minimum distance vertex visited to be true (so it won't be put back in queue again)
			sVertex.setVisited(true);
		}
	}

	//Function getShortestPathTo
	//Input: o
	//Output: Path from that vector to that one searching for it, in reverse order
	public ArrayList<Vertex> getShortestPathTo(Vertex o){
		//Creates a new ArrayList 
		ArrayList<Vertex> p = new ArrayList<Vertex>();

		//For each vertex that is not null, get the previous vertex and add it to ArrayList
		for(Vertex vertex = o ; vertex != null; vertex = vertex.getprev()){
			p.add(vertex);
		}

		//reverse the order of ArrayList p
		Collections.reverse(p);

		//return P
		return p;
	}
	
}
