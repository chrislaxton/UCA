package project3;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javafx.scene.shape.Line;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class mappanel extends JPanel{
	
	public mappanel()
	{
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension(1000, 731));
		setLayout(null);
		
		//JPanel panel = new JPanel();
		this.setBackground(Color.WHITE);
		this.setBounds(0, 0, 1000, 750);
		//add(panel);
		this.setLayout(null);
		
	}
	
	public void passPath(ArrayList<Vertex> vertex){
		
		ArrayList<String> haha = new ArrayList<String>();
		
		haha.add("Key:");
		haha.add("Green is the Start");
		haha.add("Yellow is the Path");
		haha.add("Red is the End");
		
		ArrayList<JLabel> kid = new ArrayList<JLabel>();	

		JLabel key = new JLabel("Key:");
		key.setBounds(650, 550, 150, 15);
		add(key);
		
		JLabel green = new JLabel("Green is the Start");
		green.setBounds(650, 565, 150, 15);
		green.setForeground(Color.green);
		add(green);
		
		JLabel path = new JLabel("Yellow is the Path");
		path.setBounds(650, 580, 150, 15);
		path.setForeground(Color.yellow);
		add(path);
		
		JLabel end = new JLabel("Red is the End");
		end.setBounds(650, 595, 150, 15);
		end.setForeground(Color.red);
		add(end);
	
		
		JLabel label1 = new JLabel("College Square");
		label1.setBounds(50, 29, 146, 15);
		label1.setBorder(LineBorder.createBlackLineBorder());
		label1.setHorizontalAlignment(JLabel.CENTER);
	    label1.setVerticalAlignment(JLabel.CENTER);
		add(label1);
		
		JLabel label2 = new JLabel("Lewis Science Center");
		label2.setVerticalAlignment(SwingConstants.CENTER);
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		label2.setBorder(LineBorder.createBlackLineBorder());
		label2.setBounds(164, 86, 166, 15);
		add(label2);
		
		JLabel label3 = new JLabel("Torreyson Library");
		label3.setVerticalAlignment(SwingConstants.CENTER);
		label3.setHorizontalAlignment(SwingConstants.CENTER);
		label3.setBorder(LineBorder.createBlackLineBorder());
		label3.setBounds(221, 204, 146, 15);
		add(label3);
		
		JLabel label4 = new JLabel("Speech Language Hearing");
		label4.setVerticalAlignment(SwingConstants.CENTER);
		label4.setHorizontalAlignment(SwingConstants.CENTER);
		label4.setBorder(LineBorder.createBlackLineBorder());
		label4.setBounds(597, 50, 203, 15);
		add(label4);
		
		JLabel label5 = new JLabel("Burdick");
		label5.setVerticalAlignment(SwingConstants.CENTER);
		label5.setHorizontalAlignment(SwingConstants.CENTER);
		label5.setBorder(LineBorder.createBlackLineBorder());
		label5.setBounds(403, 142, 146, 15);
		add(label5);
		
		JLabel label6 = new JLabel("Math-Comp Science");
		label6.setVerticalAlignment(SwingConstants.CENTER);
		label6.setHorizontalAlignment(SwingConstants.CENTER);
		label6.setBorder(LineBorder.createBlackLineBorder());
		label6.setBounds(196, 142, 146, 15);
		add(label6);
		
		JLabel label7 = new JLabel("Prince Center");
		label7.setVerticalAlignment(SwingConstants.CENTER);
		label7.setHorizontalAlignment(SwingConstants.CENTER);
		label7.setBorder(LineBorder.createBlackLineBorder());
		label7.setBounds(10, 204, 146, 15);
		add(label7);
		
		JLabel label8 = new JLabel("Police Dept");
		label8.setVerticalAlignment(SwingConstants.CENTER);
		label8.setHorizontalAlignment(SwingConstants.CENTER);
		label8.setBorder(LineBorder.createBlackLineBorder());
		label8.setBounds(10, 340, 146, 15);
		add(label8);
		
		JLabel label9 = new JLabel("Student Health Center");
		label9.setVerticalAlignment(SwingConstants.CENTER);
		label9.setHorizontalAlignment(SwingConstants.CENTER);
		label9.setBorder(LineBorder.createBlackLineBorder());
		label9.setBounds(50, 469, 203, 15);
		add(label9);
		
		JLabel label10 = new JLabel("Fine Art");
		label10.setVerticalAlignment(SwingConstants.CENTER);
		label10.setHorizontalAlignment(SwingConstants.CENTER);
		label10.setBorder(LineBorder.createBlackLineBorder());
		label10.setBounds(196, 340, 146, 15);
		add(label10);
		
		JLabel label11 = new JLabel("McAlister Hall");
		label11.setVerticalAlignment(SwingConstants.CENTER);
		label11.setHorizontalAlignment(SwingConstants.CENTER);
		label11.setBorder(LineBorder.createBlackLineBorder());
		label11.setBounds(387, 340, 146, 15);
		add(label11);
		
		JLabel label12 = new JLabel("Maintenance College");
		label12.setVerticalAlignment(SwingConstants.CENTER);
		label12.setHorizontalAlignment(SwingConstants.CENTER);
		label12.setBorder(LineBorder.createBlackLineBorder());
		label12.setBounds(654, 251, 146, 15);
		add(label12);
		
		JLabel label13 = new JLabel("Old Main");
		label13.setVerticalAlignment(SwingConstants.CENTER);
		label13.setHorizontalAlignment(SwingConstants.CENTER);
		label13.setBorder(LineBorder.createBlackLineBorder());
		label13.setBounds(196, 273, 146, 15);
		add(label13);
		
		JLabel label14 = new JLabel("Student Center");
		label14.setVerticalAlignment(SwingConstants.CENTER);
		label14.setHorizontalAlignment(SwingConstants.CENTER);
		label14.setBorder(LineBorder.createBlackLineBorder());
		label14.setBounds(220, 397, 146, 15);
		add(label14);
		
		JLabel label15 = new JLabel("Wingo");
		label15.setVerticalAlignment(SwingConstants.CENTER);
		label15.setHorizontalAlignment(SwingConstants.CENTER);
		label15.setBorder(LineBorder.createBlackLineBorder());
		label15.setBounds(410, 397, 146, 15);
		add(label15);
		
		JLabel label16 = new JLabel("New Business Building");
		label16.setVerticalAlignment(SwingConstants.CENTER);
		label16.setHorizontalAlignment(SwingConstants.CENTER);
		label16.setBorder(LineBorder.createBlackLineBorder());
		label16.setBounds(367, 481, 146, 15);
		add(label16);
		
		JLabel label17 = new JLabel("Brewer-Hegeman");
		label17.setVerticalAlignment(SwingConstants.CENTER);
		label17.setHorizontalAlignment(SwingConstants.CENTER);
		label17.setBorder(LineBorder.createBlackLineBorder());
		label17.setBounds(403, 563, 146, 15);
		add(label17);
		
		JLabel label18 = new JLabel("Bear Village Apt");
		label18.setVerticalAlignment(SwingConstants.CENTER);
		label18.setHorizontalAlignment(SwingConstants.CENTER);
		label18.setBorder(LineBorder.createBlackLineBorder());
		label18.setBounds(403, 633, 146, 15);
		add(label18);
		
		JLabel label19 = new JLabel("Oak Tree Apt");
		label19.setVerticalAlignment(SwingConstants.CENTER);
		label19.setHorizontalAlignment(SwingConstants.CENTER);
		label19.setBorder(LineBorder.createBlackLineBorder());
		label19.setBounds(654, 481, 146, 15);
		add(label19);
		
		kid.add(label1);
		kid.add(label2);
		kid.add(label3);
		kid.add(label4);
		kid.add(label5);
		kid.add(label6);
		kid.add(label7);
		kid.add(label8);
		kid.add(label9);
		kid.add(label10);
		kid.add(label11);
		kid.add(label12);
		kid.add(label13);
		kid.add(label14);
		kid.add(label15);
		kid.add(label16);
		kid.add(label17);
		kid.add(label18);
		kid.add(label19);
		
		for(int i = 0; i < vertex.size(); i++)
		{
			for(int j = 0; i < kid.size()-1; j++)
			if(vertex.get(i).toString().equals(kid.get(j).getText()))
			{
				kid.get(j).setVisible(true);
				if(i == 0)
				{
					kid.get(j).setOpaque(true);
					kid.get(j).setBackground(Color.green);
				}
				
				else if(i == vertex.size()-1)
				{
					kid.get(j).setOpaque(true);
					kid.get(j).setBackground(Color.red);
				}
				
				else
				{
					kid.get(j).setOpaque(true);
					kid.get(j).setBackground(Color.yellow);
				}
				break;
			}
		}
	}
	
	void drawLines(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
 
        g2d.drawLine(185,44,185,86);
        g2d.drawLine(65,43,65,204);
        g2d.drawLine(330,94,597,58);
        g2d.drawLine(260,101,260,142);
        g2d.drawLine(610,65,480,142);
        g2d.drawLine(700,65,700,251);
        g2d.drawLine(156,204,196,157);
        g2d.drawLine(65, 219, 65, 340);
        g2d.drawLine(240, 157, 240, 204);
        g2d.drawLine(342, 150, 403, 150);
        g2d.drawLine(420, 157, 420, 340);
        g2d.drawLine(500, 157, 690, 251);
        g2d.drawLine(280, 219, 280, 273);
        g2d.drawLine(150, 340, 196, 280);
        g2d.drawLine(156, 347, 196, 347);
        g2d.drawLine(65,355,65,469);
        g2d.drawLine(220,288,220,340);
        g2d.drawLine(342,273,387,340);
        g2d.drawLine(342,347,387,347);
        g2d.drawLine(225,355,258,397);
        g2d.drawLine(140,469,220,404);
        g2d.drawLine(253,476,403,563);
        g2d.drawLine(332,397,387,355);
        g2d.drawLine(366,404,410,404);
        g2d.drawLine(332,412,400,481);
        g2d.drawLine(533,347,654,266);
        g2d.drawLine(550,397,715,266);
        g2d.drawLine(513,481,723,266);
        g2d.drawLine(513,488,654,488);
        g2d.drawLine(470,496,470,563);
        g2d.drawLine(500,578,500,633);
        g2d.drawLine(403, 157, 310, 204);
        g2d.drawLine(730, 266, 730, 481);
        g2d.drawLine(425,397,425,355);
        g2d.drawLine(425,412,425,481);
        g2d.drawLine(654, 496, 549, 563);
        g2d.drawLine(156,211,221,211);
        
 
    }
	
    public void paint(Graphics g) {
        super.paint(g);
        drawLines(g);
    }
}
