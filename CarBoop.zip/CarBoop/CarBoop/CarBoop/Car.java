//Chris Laxton
//ID: 001164996
//Project 1 

package CarBoop;

public class Car implements CarADT {

	//Create private variables within Car class
	private String buying;
	private String maint;
	private int numDoors;
	private int numPersons;
	private String lug;
	private String safety;
	private String rating;

	//initialize an empty car
	public Car()
	{
		this.buying = null;
		this.maint = null;
		this.numDoors = 0;
		this.numPersons = 0;
		this.lug = null;
		this.safety = null;
		this.rating = null;
	}

	//pass data into car
	public Car(String buying, String maint, int numDoors, int numPersons, String lug, String safety, String rating) {

		this.buying = buying;
		this.maint = maint;
		this.numDoors = numDoors;
		this.numPersons = numPersons;
		this.lug = lug;
		this.safety = safety;
		this.rating = rating;
	}

	//Setters and Getters for Car Object
	public void setBuying (String s)
	{
		buying = s;
	}
	public void setMaint (String m)
	{
		maint = m;
	}
	public void setDoors (int numDoors)
	{
		this.numDoors = numDoors;
	}
	public void setPersons (int numPersons )
	{
		this.numPersons = numPersons;
	}
	public void setTrunk(String t)
	{
		lug = t;
	}
	public void setSafety (String s)
	{
		safety = s;
	}
	public void setRating (String c)
	{
		rating = c;
	}
	public String getRating()
	{
		return rating;
	}
	public String getBuying ()
	{
		return buying;
	}
	public String getMaint()
	{
		return maint;
	}
	public int getDoors()
	{
		return numDoors;
	}
	public int getPersons()
	{
		return numPersons;
	}
	public String getTrunk()
	{
		return lug;
	}
	public String getSafety()
	{
		return safety;
	}


	//Equals method that compares the elements between two cars
	public boolean equals(Car element)
	{
		if((this.buying.equals(element.buying)) && (this.maint.equals(element.maint)) && (this.numDoors == element.numDoors) && (this.numPersons == element.numPersons) && (this.lug.equals(element.lug)) && (this.safety.equals(element.safety)) && (this.rating.equals(element.rating)))
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean equals2(Car element)
	{
		if((this.buying.equals(element.buying)) && (this.maint.equals(element.maint)) && (this.safety.equals(element.safety)))
		{
			return true;
		}
		else {
			return false;
		}
	}
	public boolean equals3(Car element)
	{
		if((this.buying.equals(element.buying)) && (this.maint.equals(element.maint)) && (this.numDoors == element.numDoors) && (this.numPersons == element.numPersons) && (this.lug.equals(element.lug)) && (this.safety.equals(element.safety)))
		{
			return true;
		}
		else
			return false;
	}

	//toString to print the data
	public String toString()
	{
		return ("["+buying+", "+ maint+", "+numDoors+", "+numPersons+", "+lug+", "+safety+", "+rating+"]");
	}
}
