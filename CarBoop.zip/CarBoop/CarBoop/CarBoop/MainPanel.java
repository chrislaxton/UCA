package CarBoop;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;


public class MainPanel extends JPanel {
	
	//Initialize all variables
	private JTextField textField;
	private JLabel lblNewLabel;
	private JComboBox comboBox;
	private JLabel lblMatchingCars;
	private JLabel lblTradeinValue;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup1 = new ButtonGroup();
	private final ButtonGroup buttonGroup2 = new ButtonGroup();
	private final ButtonGroup buttonGroup3 = new ButtonGroup();
	private final ButtonGroup buttonGroup4 = new ButtonGroup();
	private final ButtonGroup buttonGroup5 = new ButtonGroup();
	private banana taco;
	private int deltaY = 0;
	private JPanel panel;
	private JLabel lblNewLabel_1;
	private JPanel panel_1;
	private JPanel panel_2;
	private ImageIcon image;
	private JLabel lblDoors;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblTrun;
	private JButton btnNewButton;
	private JLabel lblNewLabel_4;
	private Car goob;
	private JLabel lblValu;
	private int rope;
	private int dope;
	private Predictor turd;
	private String textFieldValue;
	private ArrayList<Car> haha;
	private JLabel lblNewLabel_5;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JPanel panel_3;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_6;
	//-----------------------------------------------------------------
	//  Sets up the panel, including the timer for the animation.
	//-----------------------------------------------------------------
	public MainPanel()
	{
		//Create new Car and Predictor
		goob = new Car();
		Predictor turd = new Predictor("./carTrain.DATA");
		
		//Set Background color of panel
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(1000, 500));
		setLayout(null);

		//Add new panel that is yellow to mainpanel
		panel = new JPanel();
		panel.setBackground(Color.YELLOW);
		panel.setBounds(539, 0, 461, 500);
		add(panel);
		panel.setLayout(null);
		panel.setVisible(false);

		//Adds new Label to panel
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_1.setBounds(24, 271, 410, 44);
		panel.add(lblNewLabel_1);

		//Adds new label to panel
		lblMatchingCars = new JLabel("Matching Cars!");
		lblMatchingCars.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMatchingCars.setBounds(179, 16, 123, 22);
		panel.add(lblMatchingCars);
		lblMatchingCars.setForeground(Color.BLACK);
		lblMatchingCars.setBackground(Color.WHITE);

		//Adds new label to panel
		lblTradeinValue = new JLabel("Trade-In Value! :");
		lblTradeinValue.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblTradeinValue.setBounds(24, 209, 384, 44);
		panel.add(lblTradeinValue);
		lblTradeinValue.setForeground(Color.BLACK);

		//Create a comboBox and add it to panel
		comboBox = new JComboBox();
		comboBox.setBounds(24, 49, 415, 44);
		panel.add(comboBox);

		//Create new label and add it to panel
		lblNewLabel_5 = new JLabel("WOWZERS! That is an exact match to one of our cars in the database!");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_5.setBounds(24, 172, 415, 19);
		panel.add(lblNewLabel_5);

		//Create a new panel and add it to mainpanel
		panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(0, 0, 541, 500);
		add(panel_1);
		panel_1.setLayout(null);
		//Set the visibility to be false
		panel_1.setVisible(false);

		//Adds new label to panel_1
		lblNewLabel = new JLabel("Enter Purchase Value of Car!\r\n");
		lblNewLabel.setBounds(91, 8, 196, 14);
		panel_1.add(lblNewLabel);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.GREEN);

		//Adds new textField to panel_1
		textField = new JTextField();
		textField.setBounds(297, 5, 86, 20);
		panel_1.add(textField);
		textField.setColumns(10);

		//Create new button in panel_1
		btnNewButton = new JButton("Process Results");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//Sets panel_2 visibility to false
				panel_2.setVisible(false);
				//Sets panel visibility to true
				panel.setVisible(true);
				//Reset Combobox
				comboBox.removeAllItems();
				lblNewLabel_1.setText("");
				int frappy = 0;
				textFieldValue = textField.getText();
				
				//Assign the selections from button to a new car
				goob.setBuying(buttonGroup5.getSelection().getActionCommand());
				String bogo = buttonGroup.getSelection().getActionCommand();
				if(bogo == "more")
				{
					bogo = "5";
				}
				rope = Integer.parseInt(bogo);
				goob.setDoors(rope);
				goob.setMaint(buttonGroup2.getSelection().getActionCommand());
				String pogo = buttonGroup1.getSelection().getActionCommand();
				if(pogo == "5more")
				{
					pogo = "5";
				}
				dope = Integer.parseInt(pogo);
				goob.setPersons(dope);
				goob.setSafety(buttonGroup4.getSelection().getActionCommand());
				goob.setTrunk(buttonGroup3.getSelection().getActionCommand());
				haha = turd.getPrediction(goob);


				//If one exact match , add only 1 item to combobox
				if (haha.size()>1)
				{
					for(int i = 0; i < haha.size(); i++)
					{
						lblNewLabel_5.setVisible(false);
						comboBox.addItem(haha.get(i));
					}
				}
				//If more than 1, then add all to combobox
				else if(haha.size() == 1)
				{
					lblNewLabel_5.setVisible(true);
					comboBox.addItem(haha);
				}

				//Get text of TextField
				String pookie = textField.getText();
				String cookie = "";

				//While frappy is not entered (or less than 0) then try / catch
				do {
					try {
						frappy = Integer.parseInt(pookie);
					} catch (Exception e) {
						textField.setText("");
						JOptionPane.showMessageDialog(null, "Hey Doofus! Check to See How Much They Paid for the Car!");

					} 
				} while (frappy < 0);

				//If comboBox selected index is 0 
				if(comboBox.getSelectedIndex() == 0)
				{
					Car hoop = new Car();
					hoop = haha.get(0);
					cookie = hoop.getRating();
				}

				//If comboBox selected index is 1
				else if(comboBox.getSelectedIndex() == 1)
				{
					Car hoop = new Car();
					hoop = haha.get(1);
					cookie = hoop.getRating();

				}

				//If comboBox selected index is 2
				else if(comboBox.getSelectedIndex() == 2)
				{
					Car hoop = new Car();
					hoop = haha.get(2);
					cookie = hoop.getRating();
				}

				//value of frappy depends on rating of the car they entered
				if(cookie.equals("unacc"))
				{
					if(frappy < 8 && frappy > 0)
					{
						frappy = 1;
					}
					else
						frappy = frappy/8;
				}
				else if(cookie.equals("acc"))
				{
					if(frappy < 6 && frappy > 0)
					{
						frappy = 1;
					}
					else
						frappy = frappy/6;
				}
				else if(cookie.equals("good"))
				{
					if(frappy < 4 && frappy > 0)
					{
						frappy = 1;
					}
					else
						frappy = frappy/4;
					
				}
				else if(cookie.equals("vgood"))
				{
					if(frappy < 2 && frappy > 0)
					{
						frappy = 1;
					}
					else
						frappy = frappy/2;
				}

				if (frappy > 0)
				{
					if(frappy == 1)
					{
						lblNewLabel_1.setText(String.valueOf(frappy) + "  Dollar. What A Bummer!");
					}
					else
						//Set trade - in value to value of frappy
						lblNewLabel_1.setText(String.valueOf(frappy) + "  Dollars");
					//Reset input paid value
					textField.setText("");
				}
				
			}
		});
		btnNewButton.setBounds(128, 420, 146, 23);
		panel_1.add(btnNewButton);

		//Adds new label to panel_1
		lblDoors = new JLabel("Doors");
		lblDoors.setForeground(Color.GREEN);
		lblDoors.setBounds(46, 60, 46, 14);
		panel_1.add(lblDoors);

		//Adds new label to panel_1
		lblNewLabel_2 = new JLabel("People");
		lblNewLabel_2.setForeground(Color.GREEN);
		lblNewLabel_2.setBounds(162, 60, 46, 14);
		panel_1.add(lblNewLabel_2);

		//adds new label to panel_1
		lblNewLabel_3 = new JLabel("Maint");
		lblNewLabel_3.setForeground(Color.GREEN);
		lblNewLabel_3.setBounds(276, 60, 46, 14);
		panel_1.add(lblNewLabel_3);

		//adds new label to panel_1
		lblTrun = new JLabel("Trunk Size");
		lblTrun.setForeground(Color.GREEN);
		lblTrun.setBounds(31, 245, 94, 14);
		panel_1.add(lblTrun);

		//adds new label to panel_1
		lblNewLabel_4 = new JLabel("Safety");
		lblNewLabel_4.setForeground(Color.GREEN);
		lblNewLabel_4.setBounds(162, 245, 46, 14);
		panel_1.add(lblNewLabel_4);

		//adds new label to panel_1
		lblValu = new JLabel("Value Paid");
		lblValu.setForeground(Color.GREEN);
		lblValu.setBounds(276, 245, 73, 14);
		panel_1.add(lblValu);

		//creates new panel and adds to mainpanel
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(539, 0, 461, 500);
		add(panel_2);

		//Set background image of panel_2 to this png
		image = new ImageIcon (this.getClass().getResource("/CarBoop/yolo.png"));
		panel_2.add(new JLabel(image), BorderLayout.SOUTH);
		panel_2.setVisible(false);
		
		//Create new panel and add to mainpanel
		panel_3 = new JPanel();
		panel_3.setBackground(Color.BLACK);
		panel_3.setBounds(0, 0, 1000, 500);
		add(panel_3);
		panel_3.setLayout(null);
		
		//Create new textfield and add a listener
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//Get the string values of password and username
				String password = String.valueOf(passwordField.getPassword());
				String text = String.valueOf(textField_1.getText());
				//If enter is pressed
				if (e.getKeyCode() == KeyEvent.VK_ENTER)
				{
					//Reset text values of username and password
					textField_1.setText("");
					passwordField.setText("");
					//If the string entered is correct
					if((text.equals("Chris") || text.equals("chris")) && password.equals("isCool"))
					{
						panel_3.setVisible(false);
						panel_1.setVisible(true);
						panel_2.setVisible(true);
					}
					//else show a dialog box that tells them they are wrong
					else
					{
						JOptionPane.showMessageDialog(null, "Incorrect Username / Password! HINT: Username: Chris, Password: isCool");
					}
				}
			}
		});
		textField_1.setBounds(450, 225, 100, 20);
		panel_3.add(textField_1);
		textField_1.setColumns(10);
		
		//Creates new password and adds to panel_3
		passwordField = new JPasswordField();
		//Listener
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//Get the string values of password and username
				String password = String.valueOf(passwordField.getPassword());
				String text = String.valueOf(textField_1.getText());
				//If enter is pressed
				if (e.getKeyCode() == KeyEvent.VK_ENTER)
				{
					//Reset string values of password and username
					textField_1.setText("");
					passwordField.setText("");
					//If string values are equal to right input
					if((text.equals("Chris") || text.equals("chris")) && password.equals("isCool"))
					{
						panel_3.setVisible(false);
						panel_1.setVisible(true);
						panel_2.setVisible(true);
					}
					//Else show error message dialogbox
					else
					{
						JOptionPane.showMessageDialog(null, "Incorrect Username / Password! HINT: Username: Chris, Password: isCool");
					}
				}
			}
		});
		passwordField.setBounds(450, 250, 100, 20);
		panel_3.add(passwordField);
		
		//Adds new label to panel_3
		lblNewLabel_6 = new JLabel("Username:");
		lblNewLabel_6.setForeground(Color.GREEN);
		lblNewLabel_6.setBounds(350,225,85, 20);
		panel_3.add(lblNewLabel_6);
		
		//Adds new label to panel_3
		lblNewLabel_7 = new JLabel("Password:");
		lblNewLabel_7.setForeground(Color.GREEN);
		lblNewLabel_7.setBounds(350, 250, 85, 20);
		panel_3.add(lblNewLabel_7);
		
		//Adds new label to panel_3
		lblNewLabel_8 = new JLabel("Press Enter To Login!");
		lblNewLabel_8.setForeground(Color.GREEN);
		lblNewLabel_8.setBounds(390, 175, 200, 50);
		panel_3.add(lblNewLabel_8);
		

		//Create a new banana object
		taco = new banana();
		
		//Gets door strings and adds to buttongroup
		ArrayList<String> results = taco.getDoors();
		for (String s : results) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(30, 80+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 29;
		}

		deltaY = 0;

		//Gets persons strings and adds to buttongroup1
		ArrayList<String> results1 = taco.getPersons();
		for (String s : results1) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup1.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(140, 80+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 29;
		}

		deltaY = 0;

		//Gets maint strings and adds to buttongroup2
		ArrayList<String> results2 = taco.getMaint();
		for (String s : results2) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup2.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(250, 80+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 27;
		}

		deltaY = 0;


		//Get trunk strings and adds to buttongroup3
		ArrayList<String> results3 = taco.getTrunk();
		for (String s : results3) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup3.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(30, 280+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 29;
		}

		deltaY = 0;

		//gets Safety strings and adds to buttongroup4
		ArrayList<String> results4 = taco.getSafety();
		for (String s : results4) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup4.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(140, 280+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 29;
		}

		deltaY = 0;

		//Get value strings and adds to buttongroup5
		ArrayList<String> results5 = taco.getValue();
		for (String s : results5) {
			JRadioButton rdbtnRb = new JRadioButton(s);
			buttonGroup5.add(rdbtnRb);
			if (deltaY ==0)
				rdbtnRb.setSelected(true);
			rdbtnRb.setBounds(250, 280+deltaY, 100, 25);
			rdbtnRb.setActionCommand(s);
			panel_1.add(rdbtnRb);
			deltaY += 29;
		}

		deltaY = 0;


	}
}