package CarBoop;

import java.util.ArrayList;

public class banana {
	
	private ArrayList<String> myDoors;
	private ArrayList<String> myPersons;
	private ArrayList<String> mySafety;
	private ArrayList<String> myTrunk;
	private ArrayList<String> myMaint;
	private ArrayList<String> myValue;
	
	public banana() {
		myValue = new ArrayList<String>();
		myValue.add("low");
		myValue.add("med");
		myValue.add("high");
		myValue.add("vhigh");
		
		myDoors = new ArrayList<String>();
		myDoors.add("2");
		myDoors.add("4");
		myDoors.add("more");
		
		myPersons = new ArrayList<String>();
		myPersons.add("2");
		myPersons.add("3");
		myPersons.add("4");
		myPersons.add("5more");
		
		myMaint = new ArrayList<String>();
		myMaint.add("low");
		myMaint.add("med");
		myMaint.add("high");
		myMaint.add("vhigh");
		
		myTrunk = new ArrayList<String>();
		myTrunk.add("small");
		myTrunk.add("med");
		myTrunk.add("big");
		
		mySafety = new ArrayList<String>();
		mySafety.add("low");
		mySafety.add("med");
		mySafety.add("high");
	}
	public ArrayList<String> getDoors() {
		return myDoors;
	}
	
	public ArrayList<String> getPersons(){
		return myPersons;
	}
	
	public ArrayList<String> getMaint() {
		return myMaint;
	}
	
	public ArrayList<String> getTrunk() {
		return myTrunk;
	}
	
	public ArrayList<String> getSafety() {
		return mySafety;
	}
	
	public ArrayList<String> getValue() {
		return myValue;
	}
}
