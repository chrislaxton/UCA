//Chris Laxton
//ID: 001164996
//Project 1 

package CarBoop;

public interface CarADT {
	public void setBuying (String s);
	public void setMaint (String m);
	public void setDoors (int numDoors);
	public void setPersons (int numPersons ); 
	public void setTrunk(String t);
	public void setSafety (String s);
	public void setRating (String c);
	public String getRating();
}
