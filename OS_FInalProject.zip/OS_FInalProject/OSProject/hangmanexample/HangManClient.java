//Chris Laxton

package hangmanexample;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import hangmanexample.HangManClient;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JButton;

public class HangManClient {
	
	//Private Data Variables
	private JFrame frame = new JFrame("Hang The Man");
    private JLabel messageLabel;

    private static int PORT = 8050;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private JTextField textField;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    private JLabel label;
    private JLabel label_1;
    private String guess;

    public HangManClient(String serverAddress) throws Exception {

        // Setup networking
        socket = new Socket(serverAddress, PORT);
        in = new BufferedReader(new InputStreamReader(
            socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        // Layout GUI
        messageLabel = new JLabel("New Label");
        messageLabel.setForeground(Color.BLACK);
        messageLabel.setBounds(10,250,400,20);
        frame.getContentPane().add(messageLabel);
        
    	frame.getContentPane().setBackground(Color.WHITE);
    	frame.getContentPane().setLayout(null);
    	
    	lblNewLabel = new JLabel("New label");
    	lblNewLabel.setForeground(Color.BLACK);
    	lblNewLabel.setBounds(10, 14, 191, 17);
    	frame.getContentPane().add(lblNewLabel);
    	
    	lblNewLabel_1 = new JLabel("");
    	lblNewLabel_1.setForeground(Color.BLACK);
    	lblNewLabel_1.setBounds(10, 91, 233, 20);
    	frame.getContentPane().add(lblNewLabel_1);
    	
    	textField = new JTextField();
    	textField.setBounds(211, 12, 86, 20);
    	frame.getContentPane().add(textField);
    	textField.setColumns(10);
    	
    	label = new JLabel("");
    	label.setForeground(Color.BLACK);
    	label.setBounds(10, 122, 233, 20);
    	frame.getContentPane().add(label);
    	
    	
    	label_1 = new JLabel("");
    	label_1.setForeground(Color.BLACK);
    	label_1.setBounds(10, 153, 233, 20);
    	frame.getContentPane().add(label_1);
    	
        JButton btnS = new JButton("Send");
    	btnS.addMouseListener(new MouseAdapter() {
    		@Override
    		public void mouseClicked(MouseEvent arg0) {
    			out.println("GUESS"+textField.getText());
    			textField.setText("");
    		}
    	});
    	btnS.setBounds(211, 57, 89, 23);
    	frame.getContentPane().add(btnS);
    	frame.setBackground(Color.BLACK);
       
    }

    public void play() throws Exception {
    	//Set Local Variables
    	int counter = 0;
        String response;
        ArrayList<String> bob = new ArrayList<String>();
        
        //Running the Clients
        try {
        	//Create an input buffer reader
            response = in.readLine();
            
            //If input starts with WELCOME then set frame title.
            if (response.startsWith("WELCOME")) {
                frame.setTitle("Hang Man!");
                //Get Which client this is
                char mark = response.charAt(8);
                if(mark == 'M')
                {
                	//If it is first client tell them to enter a word in
                	lblNewLabel.setText("Enter A Word For Player to Guess:" );
                }
                //If it is second client
                else if(mark == 'G')
                {
                	//Set up Labels
                	lblNewLabel_1.setText("Total Number of Guesses: 6");
                	lblNewLabel.setText("Enter A Letter To Guess!: ");
                	label.setText("Guesses Used: "+counter);
                	counter++;
                }
               
                
            }
            while (true) {
            	//While input.bufferreader is going
                response = in.readLine();
                if (response.startsWith("PLAYERGUESS"))
                {
                	//Adds the letter entered back into an arraylist of strings
                	bob.add(response.substring(11));
                	//Sets up all of the labels for client 2 with specific values
                	label_1.setText("Letters Guessed: " + bob.toString());
                	messageLabel.setText("You Guessed: " + response.substring(11));
                	textField.setText("");
                	counter++;
                	label.setText("Guesses Used: "+(counter-1));
                }
              
                //Victory Message
                else if (response.startsWith("VICTORY")) {
                	messageLabel.setText("You Won!");
                	break;
                //Loser Message
                } else if (response.startsWith("DEFEAT")) {
                	messageLabel.setText("You Lost!");
                	break;
                }
                //Message message
                else if (response.startsWith("MESSAGE")) 
                {
                    messageLabel.setText(response.substring(8));
                }
                //Gets the car name message
                else if(response.startsWith("WORDIS"))
                {
                	label_1.setText("Word is: "+response.substring(6, response.length()));
                }
              /*  else if (response.startsWith("OPP"))
                {
                	label_1.setText("Letter Guessed Are: "+response.substring(3));
                }*/
            }
            //Quit
            out.println("QUIT");
        }
        finally {
        	//Close Socket
            socket.close();
        }
    }

    //Do they want to play again? Send dialog box to them
    private boolean wantsToPlayAgain() {
        int response = JOptionPane.showConfirmDialog(frame,
            "Want to play again?",
            "Come on!",
            JOptionPane.YES_NO_OPTION);
        frame.dispose();
        return response == JOptionPane.YES_OPTION;
    }
    
    
    //Main for the client. Gets new server address from argument and then creates the client.

    public static void main(String[] args) throws Exception {
        while (true) {
            String serverAddress = (args.length == 0) ? "localhost" : args[0];
            HangManClient client = new HangManClient(serverAddress);
            client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            client.frame.setSize(500, 400);
            client.frame.setVisible(true);
            client.frame.setResizable(false);
            client.play();
            if (!client.wantsToPlayAgain()) {
                break;
            }
        }
    }
}

