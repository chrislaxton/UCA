//Chris Laxton

package hangmanexample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextField;

import hangmanexample.Game;
import hangmanexample.Game.Player;

public class HangManServer {

	//Main.
	//Implements a Game 
	//Adds two new players (clients) to the game
	//Sets the opponent to each
	//currentPlayer = player1
	//Start
	public static void main(String[] args) throws Exception {
        ServerSocket listener = new ServerSocket(8050);
        System.out.println("HangMan Server Is Now Running!");
        try {
            while (true) {
                Game game = new Game();
                Game.Player player1 = game.new Player(listener.accept(), 'M');
                Game.Player player2 = game.new Player(listener.accept(), 'G');
                player1.setOpponent(player2);
                player2.setOpponent(player1);
                game.currentPlayer = player1;
                player1.start();
                player2.start();
            }
        } finally {
            listener.close();
        }
    }
}


//Game Class
class Game {
	//Declare Global Variables
	String word;
	String wordy;
	int count;
    Player currentPlayer;

    //Test true or false to see if player2 has guessed the word
    public boolean guessedWord() {
    	int igloo = 0;
    	
    	for(int i = 0; i < wordy.length()-1;i++)
    	{
    		for(int j = 0; j <word.length()-1;j++)
    		{
    			if(word.charAt(j)==(wordy.charAt(i)))
    			{
    				igloo++;
    				if (count!=0)
    				{
    					count--;
    				}
    				if(igloo == word.length()+1);
    				{
    					return true;
    				}
    			}
    		}
    	}
        return false;
    }
        

    //Implemented thread class inside the Game class
    class Player extends Thread {
    	//Global Variables
        char mark;
        Player opponent;
        Socket socket;
        BufferedReader input;
        PrintWriter output;

        //Constructor for the Player Class
        public Player(Socket socket, char mark) {
            this.socket = socket;
            this.mark = mark;
            //Creates an input and output bufferreader
            try {
                input = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
                output = new PrintWriter(socket.getOutputStream(), true);
                output.println("WELCOME " + mark);
                output.println("MESSAGE Waiting for opponent to connect");
            } catch (IOException e) {
                System.out.println("Player died: " + e);
            }
        }


        //Sets opponent
        public void setOpponent(Player opponent) {
            this.opponent = opponent;
        }

        //playerguess function
        public void playerguess(String letter) {
        	//If mark = 'M' (First Client) then it will set the word to that string passed in
        	if (mark == 'M')
        	{
        		wordIs(letter);
        		word = letter;
        		
        	}
        	//Let player 2 take over
    		currentPlayer = currentPlayer.opponent;
        	if (mark == 'G');
        	{
        		//Check to see if player 2 has matched the word
        		boolean ugly;
        		ugly = guessedWord();
               // currentPlayer.opponent.otherPlayerGuessed(word);
        		//output the playerguess letter
        		output.println("PLAYERGUESS"+letter);
        		//Once a match is found, it will come up with You Win!
        		if(ugly == true)
        		{
        			output.println("VICTORY");
        		}
        	}
        }
        
        //Displays the word in Client 1 that is trying to get solved
        public void wordIs(String letter)
        {
        	output.println("WORDIS"+letter);
        }
        
    /*    public void otherPlayerGuessed(String turd) {
            output.println("OPP" + turd);*/
     //   }


        //Runs the threads
        public void run() {
            try {
            	//Lets all players know they are connected
                output.println("MESSAGE All players connected");
                //If it is the first client, let them know to end a word in
                if (mark == 'M') {
                    output.println("MESSAGE Make The Other Player Guess Your Word! (ENTER A WORD)");
                }
                while (true) {
                	String fun = input.readLine();
                    if (fun.startsWith("GUESS"))
                    {
                    	//If first client, send in string to playerguess
                    	if(mark=='M')
                    	{
                    		playerguess(fun.substring(5, fun.length()));
                    	}
                    	else if(mark=='G')
                		{
                    		//If second client, send in string to playerguess after concatenating string into wordy
                			wordy = wordy+fun.substring(5);
                			count++;
                			playerguess(fun.substring(5));
                			//Once a guess limit is reached, display You Lost!
                			if(count==6)
                        	{
                        		output.println("DEFEAT");
                        	}
                		}
                    }
                    //Or quit
                    else if (fun.startsWith("QUIT"))
                    {
                        return;
                    }
                    else 
                    {
                        output.println("MESSAGE What Do You Guess Next?");
                    }
                }
                //Exception
            } catch (IOException e) {
                System.out.println("Player died: " + e);
            } finally {
            	//Close the socket on disconnect
                try {socket.close();} catch (IOException e) {}
            }
        }
    }
}
